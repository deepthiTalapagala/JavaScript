function reg(){
    //alert("Enter Your Details")
    let fname=document.querySelector("#fname").value;
    let lname=document.querySelector("#lname").value;
    let gender=document.getElementsByName("gender");
    let email=document.querySelector("#email").value;
    let password=document.querySelector("#pwd").value;
    let cpassword=document.querySelector("#cpwd").value;
    let address=document.querySelector("#address").value;
    let qul=document.querySelector("#qual").value;
    let check=document.querySelector("#checkbox").checked;
    
    if(fname.length===0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please Enter Fname</b>"
    }
    else if(fname.length<5){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Fname Should min 5 Charectors</b>"
    }
    else if(lname.length===0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please Enter Lname</b>"    
    }
    else if(!(gender[0].checked||gender[1].checked||gender[2].checked)){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please Select Gender</b>"    
    }
    else if(email.length===0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Enter mail</b>"
    }
    else if(password.length===0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Enter Pwd</b>"
    }
    else if(cpassword.length==0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Enter C Pwd</b>"
    }
    else if(password!==cpassword){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Check your Password</b>"
    }
    else if(address.length===0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Enter Address</b>"
    }
    else if(qul.length===0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Select Your Qualification</b>"
    }
    else if(check===false){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Accept All Conditions</b>"
    }
    else{
        document.querySelector("#msg").innerHTML="<b class='text-success'>Register Successfully</b>"
    }
}