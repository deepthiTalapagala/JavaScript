// Header Styles
const header=[
    {url:"facebook.html", icon:"fa-brands fa-facebook-f", text:""},
    {url:"twitter.html", icon:"fa-brands fa-twitter", text:""},
    {url:"google-plus.html", icon:"fa-brands fa-google-plus-g", text:""},
    {url:"linkedin.html", icon:"fa-brands fa-linkedin-in", text:""},
    {url:"phone.html", icon:"fa-solid fa-phone-flip", text:"+02138577755"}
]
/*-----for----- */

/*var p="";
for(let x=0; x<header.length; x++){
    if(header[x].text==0){
        p+='<li class="nav-item"><a href="'+header[x].url+'" class="nav-link text-white"><i class="'+header[x].icon+'"></i></a></li>'
    }
    else{
        p+='<li class="nav-item ms-auto"><a href="'+header[x].url+'" class="nav-link text-white"><i class="'+header[x].icon+'"></i><span> '+header[x].text+'</span></a></li>'
    }
        
}*/

/*-----for in----- */

/*var p="";
for(let x in header){
    if(header[x].text==0){
        p+='<li class="nav-item"><a href="'+header[x].url+'" class="nav-link text-white"><i class="'+header[x].icon+'"></i></a></li>'
    }
    else{
        p+='<li class="nav-item ms-auto"><a href="'+header[x].url+'" class="nav-link text-white"><i class="'+header[x].icon+'"></i><span> '+header[x].text+'</span></a></li>'
    }
        
}*/

/*-----for of----- */

var p="";
for(let x of header){
    if(x.text==0){
        p+='<li class="nav-item"><a href="'+x.url+'" class="nav-link text-white"><i class="'+x.icon+'"></i></a></li>'
    }
    else{
        p+='<li class="nav-item ms-auto"><a href="'+x.url+'" class="nav-link text-white"><i class="'+x.icon+'"></i><span> '+x.text+'</span></a></li>'
    }
        
}
document.getElementById("head").innerHTML=p


// Navbar Styles
const nav=[
    {url:"home.html", name:"Home", sub:[]},
    {url:"about.html", name:"About", sub:[]},
    {url:"services.html", name:"Services", sub:[]},
    {url:"dropdown.html", name:"Drop down", sub:[
        {url:"loans.html", name:"Loans Offer"},
        {url:"form.html", name:"Application form"},
        {url:"news.html", name:"News updates"}
    ]},
    {url:"contact.html", name:"Contact", sub:[]}
]

/*-----for----- */


/*var q="";
for(let x=0; x<nav.length; x++){
    if(nav[x].sub.length===0){
        q+='<li class="nav-item px-2"><a href="'+nav[x].url+'" class="nav-link">'+nav[x].name+'</a></li>'
    }
    else{
        q+='<li class="nav-item dropdown px-2"><a href="'+nav[x].url+'"class="nav-link dropdown-toggle" data-bs-toggle="dropdown">'+nav[x].name+'</a><div class="dropdown-menu">'

        for(let r=0; r<nav[x].sub.length; r++){
            q+='<a href="'+nav[x].sub[r].url+'" class="dropdown-item">'+nav[x].sub[r].name+'</a>'
        }
        q+='</div></li>'
    }
}*/


/*-----for of----- */
var q="";
for(let x of nav){
    if(x.sub.length===0){
        q+='<li class="nav-item px-2"><a href="'+x.url+'" class="nav-link">'+x.name+'</a></li>'
    }
    else{
        q+='<li class="nav-item dropdown px-2"><a href="'+x.url+'"class="nav-link dropdown-toggle" data-bs-toggle="dropdown">'+x.name+'</a><div class="dropdown-menu">'

        for(let y of x.sub){
            q+='<a href="'+y.url+'" class="dropdown-item">'+y.name+'</a>'
        }
        q+='</div></li>'
    }
}
document.getElementById("nav").innerHTML=q;

// Banner Styles
/*const banner=[
    {class:"carousel-item active", src:"images/14.jpg", alt:"img14", heading:"Make Your Dream Come<br> True", par:"Lorem ipsum, dolor sit amet consectetur adipisicing elit. Libero temporibus, modi aliquid."},
    {class:"carousel-item", src:"images/15.jpg", alt:"img15", heading:"Find the<br> perfect loan<br> for you..", par:"Lorem ipsum, dolor sit amet consectetur adipisicing elit. Libero temporibus, modi aliquid."},
    {class:"carousel-item", src:"images/16.webp", alt:"img16", heading:"We Are Expert In<br> Approving Different Loans", par:"Lorem ipsum, dolor sit amet consectetur adipisicing elit."}
]

var a="";
for(let x=0; x<banner.length; x++){
    a+='<div class="'+banner[x].class+'"><img src="'+banner[x].src+'" alt="'+banner[x].alt+'" class="img-fluid"><div class="carousel-caption"><h2>'+banner[x].heading+'</h2><p>'+banner[x].par+'p><p><a href="">Read More >></a></p></div></div>'
}
document.getElementById("banner").innerHTML=a*/

//Loan Styles
const loan=[
    {icon:"fa-solid fa-house mb-3", heading:"1.Buying a Home", para:"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Unde facilis ullam temporibus repudiandae sequi, est nostrum mollitia! Labore ad atque odit consequatur temporibus! Laboriosam error minus, excepturi deserunt voluptates adipisci?"},
    {icon:"fa-solid fa-building mb-3", heading:"2.Refinancing", para:"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Unde facilis ullam temporibus repudiandae sequi, est nostrum mollitia! Labore ad atque odit consequatur temporibus! Laboriosam error minus, excepturi deserunt voluptates adipisci?"},
    {icon:"fa-solid fa-credit-card mb-3", heading:"3.Credit Service", para:"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Unde facilis ullam temporibus repudiandae sequi, est nostrum mollitia! Labore ad atque odit consequatur temporibus! Laboriosam error minus, excepturi deserunt voluptates adipisci?"}
]

/*-----for ----- */


/*var b="";
for(let x=0; x<loan.length; x++){
    b+='<div class="col-md-4 col-sm-6 col-12 pb-3"><div class="bg-white py-4 px-3 shadow"><i class="'+loan[x].icon+'"></i><h4>'+loan[x].heading+'</h4><p>'+loan[x].para+'</p></div></div>'
}*/

/*-----for of----- */

/*var b="";
for(let x of loan){
    b+='<div class="col-md-4 col-sm-6 col-12 pb-3"><div class="bg-white py-4 px-3 shadow"><i class="'+x.icon+'"></i><h4>'+x.heading+'</h4><p>'+x.para+'</p></div></div>'
}*/

/*----Backsticks--- */
var b="";
for(let x of loan){
    b+=`<div class="col-md-4 col-sm-6 col-12 pb-3"><div class="bg-white py-4 px-3 shadow"><i class="'+${x.icon}+'"></i><h4>'+${x.heading}+'</h4><p>'+${x.para}+'</p></div></div>`
}

document.getElementById("offer").innerHTML=b;

//Application Styles

/*const app=[
    {class:"card-body collapse show", name:"Choose Loan Amount",para:"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dicta atque quam pariatur dolorum, corrupti dolorem, officia at consequuntur, modi similique obcaecati assumenda. Dolorem dolore dicta quisquam recusandae facere sequi illo.",data-bs-target="#msg"},
    {class:"card-body collapse", name:"Get Your Loan Approved",para:"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dicta atque quam pariatur dolorum, corrupti dolorem, officia at consequuntur, modi similique obcaecati assumenda. Dolorem dolore dicta quisquam recusandae facere sequi illo."},
    {class:"card-body collapse", name:"For New Home Purchase",para:"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dicta atque quam pariatur dolorum, corrupti dolorem, officia at consequuntur, modi similique obcaecati assumenda. Dolorem dolore dicta quisquam recusandae facere sequi illo."}
]

c="";
for(x=0; x<app.length; x++){
    if(app[x].class=="card-body collapse show"){
        c+='<div class="card mb-3"><div class="card-header" data-bs-target="#msg" data-bs-toggle="collapse"><h6><i class="fa-solid fa-check"></i> '+app[x].name+'</h6></div><div class="card-body collapse show" id="msg" data-bs-parent="#card-style"><p>'+app[x].para+'</p></div></div>'
    }
    else{
        c+='<div class="card mb-3"><div class="card-header" data-bs-target="#msg" data-bs-toggle="collapse"><h6><i class="fa-solid fa-check"></i> '+app[x].name+'</h6></div><div class="card-body collapse" id="msg" data-bs-parent="#card-style"><p>'+app[x].para+'</p></div></div>'
    }
    
}
document.getElementById("card-style").innerHTML=c;

has to write in json then we will get this*/

//News Styles
/*const news=[
    {src:"images/2.jpg", alt:"img2"},
    {src:"images/3.jpg", alt:"img3"},
    {src:"images/4.jpg", alt:"img4"},
]

d="";
for(x=0; x<news.length; x++){
    <div class="col-md-4 col-sm-6 col-12 pb-3"><div class="card"><div class="parent"><img src="'+news[x].src+'" alt="'+news[x].alt+'" class="card-img-top img-fluid"></div><div class="card-body"><h5 class="title">Smart Moving Tips</h5><p class="content">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Id esse provident saepe est vel sunt magni architecto dolore nisi. Perspiciatis obcaecati ipsam voluptatem eos fugiat corrupti delectus quos maxime tempora.</p></div><div class="card-footer">Last Updated on Oct 25,2022</div></div></div>
}*/
