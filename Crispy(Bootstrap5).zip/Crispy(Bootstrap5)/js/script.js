//Header Style
const header=[
    {class:"nav-item text-white pe-3", icon:"fa-regular fa-envelope-open", text:"info@Example.com"},
    {class:"nav-item text-white", icon:"fa-solid fa-phone", text:"Call Us +565 487 42942"},
    {class:"nav-item text-white ms-auto", icon:"", text:"Mon-Sun : 8:30am To 9:30pm"}
]

var b="";
for(let x=0; x<header.length; x++){
    if(header[x].icon>0){
        b+='<li class="'+header[x].class+'"><i class="'+header[x].icon+'"></i> '+header[x].text+'</li>'
    }
    else{
        b+='<li class="'+header[x].class+'">'+header[x].text+'</li>'
    }
}
document.getElementById("head").innerHTML=b;


//Navbar Style
const nav=[
    {url:"home.html", name:"Home"},
    {url:"about.html", name:"About Us"},
    {url:"services.html", name:"Services"},
    {url:"gallery.html", name:"Gallery"},
    {url:"blog.html", name:"Blog"},
    {url:"contact.html", name:"Contact Us"},
    {url:"", name:"CALL US"},
]

var a="";
for(let x=0; x<nav.length; x++){
    if(nav[x].url==0){
        a+='<li class="nav-item px-2"><button type="button"  class="nav-link py-2 px-4">'+nav[x].name+'</button></li>'
    }
    else{
        a+='<li class="nav-item px-2"><a href="'+nav[x].url+'" class="nav-link text-white">'+nav[x].name+'</a></li>'
    }
}
document.getElementById("nav").innerHTML=a;

//Carousel Style
const carousel=[
    {class:"carousel-item active", p1:"Delicious & Crispy<br> <b>Recipies.", p2:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita dolorem ducimus, voluptates hic maxime, quas, officiis enim nemo repudiandae minima eos! Aliquid modi, deserunt accusamus qui ullam aliquam iusto commodi."},
    {class:"carousel-item", p1:"Vegitarian curry<br> <b>Recipies.</b>", p2:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita dolorem ducimus, voluptates hic maxime, quas, officiis enim nemo repudiandae minima eos! Aliquid modi, deserunt accusamus qui ullam aliquam iusto commodi."},
    {class:"carousel-item", p1:"Indian Vegitble<br> <b>Curry.", p2:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita dolorem ducimus, voluptates hic maxime, quas, officiis enim nemo repudiandae minima eos! Aliquid modi, deserunt accusamus qui ullam aliquam iusto commodi."}
]

var c="";
for(let x=0; x<carousel.length; x++){
    c+='<div class="'+carousel[x].class+'"><p>'+carousel[x].p1+'</p><p>'+carousel[x].p2+'</p><button class="px-4 py-2 me-2">Read More</button><button class="px-4 py-2">Contact Us</button></div>'
}
document.getElementById("crsl").innerHTML=c;


//About Us Styles
const about=[
    {icon:"fa-solid fa-cake-candles", text:"HEALTHY"},
    {icon:"fa-solid fa-rocket", text:"SPICY & HOT"},
    {icon:"fa-solid fa-utensils", text:"CRUNCHY"},
    {icon:"fa-solid fa-mug-hot", text:"RECIEPE"}
]

var d="";
for(x=0; x<about.length; x++){
    d+='<div class="col-3"><div class="circle"><i class="'+about[x].icon+'"></i></div><span>'+about[x].text+'</span></div>'
}
document.getElementById("circle-icon").innerHTML=d;

//Testimonial Styles
const test=[
    {p:"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fuga explicabo quo minus inventore, atque nam quae ab laudantium dicta excepturi neque aliquam cum? Libero ullam, tenetur quasi saepe non itaque.", src:"images/3.jpg", alt:"img3"},
    {p:"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fuga explicabo quo minus inventore, atque nam quae ab laudantium dicta excepturi neque aliquam cum? Libero ullam, tenetur quasi saepe non itaque.", src:"images/4.jpg", alt:"img4"},
    {p:"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fuga explicabo quo minus inventore, atque nam quae ab laudantium dicta excepturi neque aliquam cum? Libero ullam, tenetur quasi saepe non itaque.", src:"images/5.jpg", alt:"img5"}
]

var e="";
for(x=0; x<test.length; x++){
    e+='<div class="col-md-4 col-sm-12"><div class="div1 p-3"><i class="fa-solid fa-quote-right"></i><p>'+test[x].p+'.</p></div><div class="row p-3"><img src="'+test[x].src+'" alt="'+test[x].alt+'" class="mr-3 mt-1 rounded-circle img-fluid" ><div class="col-md-6 mt-4"><h5>Mary Jane</h5><p>- March 3, 2019.</p></div></div></div>'
}
document.getElementById("test").innerHTML=e;