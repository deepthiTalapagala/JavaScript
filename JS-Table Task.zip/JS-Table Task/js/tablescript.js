const all_courses=[
    {
        id:1,
        name:"ANGULAR DEVELOPMENT",
        img:"1.png",
        content:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis soluta labore, earum quidem consequatur qui laudantium sit hic officia, quas dolor pariatur totam ex impedit numquam corporis voluptatem minima mollitia?",
        price:20000
    },
    {
        id:2,
        name:"REACT JS DEVELOPMENT",
        img:"2.png",
        content:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis soluta labore, earum quidem consequatur qui laudantium sit hic officia, quas dolor pariatur totam ex impedit numquam corporis voluptatem minima mollitia?",
        price:25000
    },
    {
        id:3,
        name:"NODE JS DEVELOPMENT",
        img:"3.jpg",
        content:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis soluta labore, earum quidem consequatur qui laudantium sit hic officia, quas dolor pariatur totam ex impedit numquam corporis voluptatem minima mollitia?",
        price:30000
    },
    {
        id:4,
        name:"PYTHON DEVELOPMENT",
        img:"4.png",
        content:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis soluta labore, earum quidem consequatur qui laudantium sit hic officia, quas dolor pariatur totam ex impedit numquam corporis voluptatem minima mollitia?",
        price:30000
    },
    {
        id:5,
        name:"JAVA DEVELOPMENT",
        img:"5.jpg",
        content:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis soluta labore, earum quidem consequatur qui laudantium sit hic officia, quas dolor pariatur totam ex impedit numquam corporis voluptatem minima mollitia?",
        price:30000
    },
    {
        id:6,
        name:"VUE JS DEVELOPMENT",
        img:"6.jpg",
        content:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis soluta labore, earum quidem consequatur qui laudantium sit hic officia, quas dolor pariatur totam ex impedit numquam corporis voluptatem minima mollitia?",
        price:20000
    },
 
]

// var p=""
// for(let i=0;i<all_courses.length;i++){
// p+='<tr><td>'+all_courses[i].id+'</td><td>'+all_courses[i].name+'</td><td><img src="images/'+all_courses[i].img+'"></td><td>'+all_courses[i].content+'</td><td>'+all_courses[i].price+'</td></tr>'
// }
// document.getElementById("table").innerHTML=p;

var p=""
for(x of all_courses){
p+='<tr><td>'+x.id+'</td><td>'+x.name+'</td><td><img src="images/'+x.img+'"></td><td>'+x.content+'</td><td>'+x.price+'</td></tr>'
}
document.getElementById("table").innerHTML=p;

// var p=""
// for(let x in all_courses){
// p+='<tr><td>'+all_courses[x].id+'</td><td>'+all_courses[x].name+'</td><td><img src="images/'+all_courses[x].img+'"></td><td>'+all_courses[x].content+'</td><td>'+all_courses[x].price+'</td></tr>'
// }
// document.getElementById("table").innerHTML=p;