function reg(){
    let fname=document.querySelector("#fname").value;
    let lname=document.querySelector("#lname").value;
    let gender=document.getElementsByName("gender");
    let email=document.querySelector("#email").value
    let password=document.querySelector("#pwd").value
    let cpassword=document.querySelector("#cpwd").value
    let address=document.querySelector("#address").value
    let qul=document.querySelector("#qual").value
    let check=document.querySelector("#checkbox").checked

    console.log(gender)
    if(fname.length===0){
        document.querySelector("#fname-msg").innerHTML="<b class='text-danger'>Please Enter First Name</b>"
    }
    else if(lname.length===0){
        document.querySelector("#lname-msg").innerHTML="<b class='text-danger'>Please Enter Last Name</b>"
    }
    else if(!(gender[0].checked||gender[1].checked||gender[2].checked)){
        document.querySelector("#gender-msg").innerHTML="<b class='text-danger'>Please Select Gender</b>"
    }
    else if(email.length===0){
        document.querySelector("#email-msg").innerHTML="<b class='text-danger'>Please Enter Email</b>"
    }
    else if(password.length===0){
        document.querySelector("#pwd-msg").innerHTML="<b class='text-danger'>Please Enter Password</b>"
    }
    else if(cpassword.length===0){
        document.querySelector("#cpwd-msg").innerHTML="<b class='text-danger'>Please Enter CPassword</b>"
    }
    else if(password!==cpassword){
        document.querySelector("#cpwd-msg").innerHTML="<b class='text-danger'>Please Enter Correct CPassword</b>"
    }
    else if(address.length===0){
        document.querySelector("#address-msg").innerHTML="<b class='text-danger'>Please Enter Address</b>"
    }
    else if(qul.length===0){
        document.querySelector("#qul-msg").innerHTML="<b class='text-danger'>Please Select Qul</b>"
    }
    else if(check===false){
        document.querySelector("#check-msg").innerHTML="<b class='text-danger'>Accept all Consitions</b>"
    }
    else{
        document.querySelector("#msg").innerHTML="<b class='text-success'>Register Sucessfully</b>"
    }
}