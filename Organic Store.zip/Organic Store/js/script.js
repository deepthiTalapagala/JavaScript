//Nav Styles
const nav=[
    {url:"home.html", name:"Home"},
    {url:"about.html", name:"About"},
    {url:"services.html", name:"Services"},
    {url:"gallery.html", name:"Gallery"},
    {url:"blog.html", name:"Blog"},
    {url:"contact.html", name:"Contact Us"}
]

var a="";
for(let x=0;x<nav.length;x++){
    a+='<li class="nav-item px-2"><a href="'+nav[x].url+'" class="nav-link">'+nav[x].name+'</a></li>'
}
document.getElementById("nav").innerHTML=a;

//Services Styles
const services=[
    {img:"images/3.png",h:"Vegatables",p:"Lorem ipsum, dolor sit amet consectetur adipisicing elit.", alt:"img3"},
    {img:"images/4.png",h:"Fresh Fruits",p:"Lorem ipsum, dolor sit amet consectetur adipisicing elit.", alt:"img4"},
    {img:"images/5.webp",h:"Garden Tillage",p:"Lorem ipsum, dolor sit amet consectetur adipisicing elit.", alt:"img5"},
    {img:"images/6.webp",h:"Awesome Wheats",p:"Lorem ipsum, dolor sit amet consectetur adipisicing elit.", alt:"img6"},
    {img:"images/3.png",h:"Garden Tillage",p:"Lorem ipsum, dolor sit amet consectetur adipisicing elit.", alt:"img3"},
    {img:"images/4.png",h:"Agro Nachinery",p:"Lorem ipsum, dolor sit amet consectetur adipisicing elit.", alt:"img4"},
]
var b="";
for(let x=0; x<services.length;x++){
    b+='<div class="col-md-4 col-sm-12 col-12"><div class="py-4 px-3 mb-3 shadow"><img src="'+services[x].img+'" alt="'+services[x].alt+'" class="img-fluid shadow"><p class="text-success">'+services[x].h+'</p><p>'+services[x].p+'</p></div></div>'
}
document.getElementById("service").innerHTML=b;