/*function reg(){
    let fname=document.querySelector("#fname").value;
    let lname=document.querySelector("#lname").value;
    let gender=document.getElementsByName("gender");
    let phone=document.querySelector("#phone").value;
    let email=document.querySelector("#email").value;
    let password=document.querySelector("#pwd").value;
    let cpassword=document.querySelector("#cpwd").value;
    let address=document.querySelector("#address").value;
    let qul=document.querySelector("#qul").value;
    let check=document.querySelector("#checkbox").checked;

    if(fname.length==0){
        document.querySelector("#fname-msg").innerHTML="<b class='text-danger'>Please enter Fname</b>"
    }
    else if(lname.length==0){
        document.querySelector("#lname-msg").innerHTML="<b class='text-danger'>Please enter Lname</b>"
    }
    else if(!(gender[0].checked || gender[1].checked || gender[2].checked)){
        document.querySelector("#gender-msg").innerHTML="<b class='text-danger'>Please select gender</b>"
    }
    else if(phone.length==0){
        document.querySelector("#phone-msg").innerHTML="<b class='text-danger'>Please enter Phone number</b>"
    }
    else if(email.length==0){
        document.querySelector("#email-msg").innerHTML="<b class='text-danger'>Please enter email</b>"
    }
    else if(password.length==0){
        document.querySelector("#pwd-msg").innerHTML="<b class='text-danger'>Please enter Password</b>"
    }
    else if(cpassword.length==0){
        document.querySelector("#cpwd-msg").innerHTML="<b class='text-danger'>Please enter CPassword</b>"
    }
    else if(password.length!==cpassword.length){
        document.querySelector("#cpwd-msg").innerHTML="<b class='text-danger'> Check Password</b>"
    }
    else if(address.length==0){
        document.querySelector("#address-msg").innerHTML="<b class='text-danger'>Please enter Address</b>"
    }
    else if(qul.length==0){
        document.querySelector("#qul-msg").innerHTML="<b class='text-danger'>Please enter qul</b>"
    }
    else if(check===false){
        document.querySelector("#check-msg").innerHTML="<b class='text-danger'>Please accept the conditions</b>"
    }
    else{
        document.querySelector("#msg").innerHTML="<b class='text-success'>Register Successfully</b>"
    }
    // console.log(gender)
}*/

function reg(){
    let fname=document.querySelector("#fname").value;
    let lname=document.querySelector("#lname").value;
    let gender=document.getElementsByName("gender");
    let phone=document.querySelector("#phone").value;
    let email=document.querySelector("#email").value;
    let password=document.querySelector("#pwd").value;
    let cpassword=document.querySelector("#cpwd").value;
    let address=document.querySelector("#address").value;
    let qul=document.querySelector("#qul").value;
    let check=document.querySelector("#checkbox").checked;

    if(fname.length==0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please enter Fname</b>"
    }
    else if(lname.length==0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please enter Lname</b>"
    }
    else if(!(gender[0].checked || gender[1].checked || gender[2].checked)){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please select gender</b>"
    }
    else if(phone.length==0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please enter Phone number</b>"
    }
    else if(email.length==0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please enter email</b>"
    }
    else if(password.length==0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please enter Password</b>"
    }
    else if(cpassword.length==0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please enter CPassword</b>"
    }
    else if(password.length!==cpassword.length){
        document.querySelector("#msg").innerHTML="<b class='text-danger'> Check Password</b>"
    }
    else if(address.length==0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please enter Address</b>"
    }
    else if(qul.length==0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please enter qul</b>"
    }
    else if(check===false){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please accept the conditions</b>"
    }
    else{
        document.querySelector("#msg").innerHTML="<b class='text-success'>Register Successfully</b>"
    }
    // console.log(gender)
}