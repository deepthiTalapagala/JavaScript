function logout(){
    window.location.assign("login.html")
    localStorage.clear();
}

let obj = JSON.parse(localStorage.getItem("data"))
let e= localStorage.getItem("email")

if(e==null || e=="" || e.length==0){
    location.href="login.html";
}
document.getElementById("email").innerHTML=obj.user_fname;