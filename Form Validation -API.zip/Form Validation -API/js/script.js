function reg(){
    let fname= document.querySelector("#fname").value;
    let lname= document.querySelector("#lname").value;
    let phone= document.querySelector("#phone").value;
    let email= document.querySelector("#email").value;
    let password= document.querySelector("#pwd").value;
    let cpassword= document.querySelector("#cpwd").value;
    let check= document.querySelector("#checkbox").checked;


    if(fname.length==0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please enter Fname</b>"
    }
    else if(lname.length==0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please enter Lname</b>"
    }
    else if(phone.length==0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please enter phone number</b>"
    }
    else if(email.length==0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please enter email</b>"
    }
    else if(password.length==0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please enter password</b>"
    }
    else if(cpassword.length==0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please enter cpassword</b>"
    }
    else if(password.length!==cpassword.length){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please check password</b>"
    }
    else if(check===false){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Accept all Conditions</b>"
    }
    else{
        const data = new FormData();
        data.append("fname",fname)
        data.append("lname",lname)
        data.append("email",email)
        data.append("ph",phone)
        data.append("pwd",password)


        let x= new XMLHttpRequest();
        x.open("POST", "http://ilandertech.com/api/index.php/Welcome/AddStuRegister")
        x.send(data);

        console.log(x);

        x.onreadystatechange = function(){
            if(x.readyState==4 && x.status==200){
                console.log(x.response)

                let result = JSON.parse(x.response)
                console.log(result);
                document.querySelector("#msg").innerHTML= result.message

                if(result.status==1){
                    document.querySelector("#msg").style.color="green";
                    document.querySelector("#msg").style.fontWeight="bold"
                }
                else{
                    document.querySelector("#msg").style.color="red";
                    document.querySelector("#msg").style.fontweight="bold"
                }
            }
        }
    }
}