function login(){
    let email= document.querySelector("#email").value;
    let password= document.querySelector("#pwd").value;


    if(email.length==0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please enter email</b>"
    }
    else if(password.length==0){
        document.querySelector("#msg").innerHTML="<b class='text-danger'>Please enter password</b>"
    }
    else{
        const data = new FormData();
        data.append("userEmail",email)
        data.append("userPassword",password)


        let x= new XMLHttpRequest();
        x.open("POST", "http://ilandertech.com/api/index.php/Welcome/StuLogin")
        x.send(data);

        console.log(x);

        x.onreadystatechange = function(){
            if(x.readyState==4 && x.status==200){
                console.log(x.response)

                let result = JSON.parse(x.response)
                console.log(result);
                document.querySelector("#msg").innerHTML= result.message

                if(result.status==1){
                    document.querySelector("#msg").style.color="green";
                    document.querySelector("#msg").style.fontWeight="bold";
                    localStorage.setItem("email", email);
                    localStorage.setItem("data", JSON.stringify(result.data[0]))
                    window.location.href = "dashboard.html";
                }
                else{
                    document.querySelector("#msg").style.color="red";
                    document.querySelector("#msg").style.fontweight="bold"
                }
            }
        }
    }
}