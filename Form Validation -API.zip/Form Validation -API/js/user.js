function logout(){
    window.location.assign("login.html")
    localStorage.clear();
}

let obj = JSON.parse(localStorage.getItem("data"))
let e= localStorage.getItem("email")

if(e==null || e=="" || e.length==0){
    location.href="login.html";
}
document.getElementById("email").innerHTML=obj.user_fname;

function getUsers(){
    let x = new XMLHttpRequest();
    x.open("GET", "http://ilandertech.com/api/index.php/Welcome/getStuUsers")
    x.send();

    console.log("getUsers",x)

    x.onreadystatechange= function(){
        if(x.readyState==4 && this.status==200){
            console.log("response",x.response)

            let result = JSON.parse(x.response)
            console.log("result", result)

           let data= result.data;
           console.log("data", data)
           data.sort((a,b)=>b.user_id - a.user_id)

           p="";
           let sno=0;
           for(let s of data){
            sno++;
            p+=
            `
                <tr>
                    <td>${sno}</td>
                    <td>${s.user_fname}</td>
                    <td>${s.user_lname}</td>
                    <td>${s.user_email}</td>
                    <td>${s.user_phone}</td>
                    <td>${s.user_password}</td>
                </tr>
            `

           }
           document.getElementById("msg").innerHTML=p;

        }
    }
}
getUsers();